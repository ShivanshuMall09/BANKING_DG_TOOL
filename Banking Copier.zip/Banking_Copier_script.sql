USE [GSM]
GO
/****** Object:  Table [dbo].[FileMovementHistory]    Script Date: 22-12-2025 14:38:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FileMovementHistory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProcessID] [int] NOT NULL,
	[TransferType] [varchar](100) NULL,
	[FileName] [varchar](500) NULL,
	[FilePath] [varchar](500) NULL,
	[MachineCode] [varchar](100) NULL,
	[CreatedOn] [datetime] NULL,
	[IsMoved] [tinyint] NULL,
	[CreatedBy] [int] NULL,
	[Status] [tinyint] NOT NULL,
 CONSTRAINT [PK__FileMove__3214EC277B4254ED] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProcessMaster]    Script Date: 22-12-2025 14:38:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProcessMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[Status] [tinyint] NOT NULL,
 CONSTRAINT [PK__ProcessM__3214EC27EB681B15] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProgramLog]    Script Date: 22-12-2025 14:38:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProgramLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProcessID] [int] NOT NULL,
	[CreatedOn] [datetime] NULL,
	[Operation] [varchar](100) NULL,
	[FileName] [varchar](250) NULL,
	[FilePath] [varchar](max) NULL,
	[LogMsg] [varchar](max) NULL,
	[Output] [varchar](50) NULL,
	[UserID] [int] NULL,
	[MachineCode] [varchar](100) NULL,
	[Status] [tinyint] NOT NULL,
 CONSTRAINT [PK_ProgramLog] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Banking_Copier_Login]    Script Date: 22-12-2025 14:38:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Banking_Copier_Login](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Username] [varchar](50) NOT NULL,
	[Password] [varchar](50) NOT NULL,
	[Role] [int] NOT NULL,
	[IsActive] [tinyint] NOT NULL,
	[IsFirstTimeLogin] [int] NOT NULL,
	[LastPasswordChangeDate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Banking_Copier_Login] ADD  DEFAULT ((0)) FOR [IsFirstTimeLogin]
GO
/****** Object:  StoredProcedure [dbo].[usp_SaveFilePath]    Script Date: 22-12-2025 14:38:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[usp_SaveFilePath]
	@processID int,
	@transferType Varchar(100),
	@filePath varchar(500),
	@fileName Varchar(500),
	@userId int,
	@machineCode Varchar(100)
As

	INSERT INTO FileMovementHistory(ProcessID,TransferType,FilePath,FileName,CreatedOn,IsMoved,CreatedBy,MachineCode,Status)
	Values(@processID,@transferType,@filePath,@fileName,GETDATE(),1,@userId,@machineCode,0)

	SELECT CAST(SCOPE_IDENTITY() as int) AS SavedID


GO
/****** Object:  StoredProcedure [dbo].[usp_SaveProcess]    Script Date: 22-12-2025 14:38:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[usp_SaveProcess]
	@userID int
AS
	Insert INTO
		ProcessMaster(UserID,CreatedDate,Status)
		Values(@userID,GETDATE(),0)

	SELECT CAST(SCOPE_IDENTITY() as int) AS SavedID
GO
/****** Object:  StoredProcedure [dbo].[usp_UpdateProcessStatus]    Script Date: 22-12-2025 14:38:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[usp_UpdateProcessStatus]
	@processID int,
	@status int
As
	UPDATE ProcessMaster SET Status = @status WHERE ID = @processID

	UPDATE FileMovementHistory SET Status = @status WHERE ProcessID = @processID

	UPDATE ProgramLog SET Status = @status WHERE ProcessID = @processID

GO
  CREATE Procedure [dbo].[usp_SaveLog]
	@processID int,
	@operation Varchar(100),
	@fileName Varchar(250),
	@filePath Varchar(max),
	@logMsg varchar(max),
	@output varchar(50),
	@userID int,
	@machineCode Varchar(100)

  AS
	INSERT INTO
		ProgramLog (ProcessID,CreatedOn,Operation,FileName,FilePath,LogMsg,Output,UserID,MachineCode,Status)
		Values(@processID,GETDATE(),@operation,@fileName,@filePath,@logMsg,@output,@userID,@machineCode,0)

	SELECT CAST(SCOPE_IDENTITY() as int) AS SavedID